<?php
include('dbcon.php');
if(isset($_POST['rsignup']))
{
  $sql="insert into user(name,address,rnumber,rnumber1,dob,class,division,subject,course,fees)values('".$_POST['rname']."','".$_POST['address']."','".$_POST['rnumber']."','".$_POST['rnumber1']."','".$_POST['dob']."','".$_POST['class']."','".$_POST['division']."','".$_POST['subject']."','".$_POST['course']."','".$_POST['fees']."')";
  //echo $sql;exit;
  if($conn->query($sql)==TRUE)
  {
    echo '<script>alert("Account created successfully...")</script>';?>
    
    <script>window.location='index.php';</script>
  <?php
  }else
  {
    echo "Something Wrong" . $conn->error;
  }
 
}
?>

<div class="container mb-4" id="registration">
      <h2 class="text-center" style="color: white; font-weight: bold;">Create an account</h2>
      <div class="row">
        <div class="col-md-6 col-sm-6 offset-md-3 text-white" style="background-color: rgba(0, 0, 0, 0.6);">
          <form action="" method="POST" class="p-3" id="myForm">
            <div class="form-group my-1">
              <i class="fas fa-user mr-2"></i><label for="name" class="font-weight-bold">Name Of Student</label>
              <input type="text" class="form-control" placeholder="Name Of Student" name="rname">
            </div>
            <div class="form-group my-1">
              <i class="fas fa-address mr-2"></i><label for="name" class="font-weight-bold">Name Of Address</label>
              <input type="text" class="form-control" placeholder="Name Of Address" name="address">
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Contact of Student</label>
              <input type="tel" name="rnumber" class="form-control" placeholder="Enter your Mobile Number">
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Contact of Parent</label>
              <input type="tel" name="rnumber1" class="form-control" placeholder="Enter Parent Mobile Number">
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Date Of Birth</label>
              <input type="date" name="dob" class="form-control" placeholder="Enter Parent Mobile Number">
            </div>
             <div class="form-group my-1"> 
              <i class="fas fa-folder mr-2"></i><label for="mobile-number" class="font-weight-bold">Class</label>
              
              <select name="class" class="form-control">
                <option value="">Select Class</option>
                <option value="11th">11th</option>
                <option value="12th">12th</option>
              </select>
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Division</label>
              <select name="division" class="form-control">
                <option value="">Select Division</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
              </select>
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Offered Subject</label>
              <select name="subject" class="form-control">
                <option value="">Select Subject</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Math">Math</option>
                <option value="Biology">Biology</option>
              </select>
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Course Offered</label>
              <select name="course" class="form-control">
                <option value="">Select Course</option>
                <option value="Board+JEE">Board+JEE</option>
                <option value="NEET">NEET</option>
                <option value="JEE">JEE</option>
                <option value="CET">CET</option>
              </select>
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Registration Fees</label>
              <input type="number" name="fees" class="form-control" placeholder="2000/-" disabled="">
              <input type="number" name="fees" class="form-control" placeholder="Two Thousand Rs.Only" disabled="">
            </div>
            <div class="form-group my-1"> 
              <i class="fas fa-phone mr-2"></i><label for="mobile-number" class="font-weight-bold">Fees</label>
              <select name="fees" class="form-control">

              <option value="Pending">Pending Fees</option>
                <option value="Paid">Paid Fees</option></select>
            </div>
            
            
            <div class="submit" style="display: flex;">
            <button class="btn btn-danger mt-2 p-1 font-weight-bold mr-4" name="rsignup" >Submit</button>
            <p class="alert p-0 my-2 font-weight-bold"><?php if(isset($msg)) echo $msg ?></p>
            </div>

          </form>
        </div>
      </div>
    </div>