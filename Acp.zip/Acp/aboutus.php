<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="shortcut icon" href="image/L.png" type="image/png" >
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="css/all.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <style>
    .bs-example{
        margin: 22px;
    }
  </style>

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/design.css">
    <title>Avishkar Career Point</title>
</head>
<body>
    <div class="bs-example">
    <nav class="navbar navbar-expand-md sticky-top" style="background-color: rgba(0, 0, 0, 0.6);" >
        <a href="#" class="navbar-brand" style="color: white; font-weight: bold; font-size: 25px;">
          <img src="image/L.png" style="height: 70px; width: 150px;">
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse" style="background-color: #F1F0FF; border-radius: 10px; height: 30px;">
            <span class="navbar-toggler-icon">🧪</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
          <a href="" class="closebtn" onclick="closeNav" style="color:rgba(0, 0, 0, 0);">X</a>
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active"  style="color: white; font-size: 150%;">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <!-- <a href="developer.html" class="nav-item nav-link"  style="color: white;">Developer</a> -->
                 <a href="gallery.php" class="nav-item nav-link active" tabindex="-1"  style="color: white; font-size: 150%;">Gallery</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="aboutus.php" class="nav-item nav-link"  style="color: white; font-size: 150%;">About Us</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="feedback.php" class="nav-item nav-link active" tabindex="-1"  style="color: white; font-size: 150%;">Feedback</a>
            </div>
        </div>
    </nav>

<div class ="content">
      
      <div class = "head"><h1 style="color: white; text-align: center;"><b>About Us..</b></h1></div><br><b>
        <p>● I, ACP CLASSES, would like to introduce you with this institution. The main fundamental of this institution is to see smile on the faces of students, who had been from this institution, several years back. Smile? Yes, the smile.</p>  
        <p>● Smile of ACHIEVEMENT, Smile of SUCCESS, Smile of SATISFACTION.</p>
        <p>● Since 38 years, this institution and we are working our heart out for spreading this smile.</p>
        <p>● We have been constantly thinking to provide students, with whatever the best is. We have come up with lots of new ideas in the field of education under our roof, starting from coordinate geometry stencil to the formation of Ranker’s Batch.</p>
        <p>● We have given number of facilities, just for the betterment of students at no extra cost.</p>
        <p>● We have highly qualified teachers who have years of experience in the field of education and exemplary command over their own domain of study.</p>
        <p>● In addition, they are ones who understand exactly what the student needs, in terms of a nourishing and nurturing academic guidance.</p>
        <p><b><h2>Mission</h2></b></p>
        <p>● Innovating teaching practices into ones that strengthen the teaching-learning process, our mission is to stimulate the spirit of scientific enquiry and discovery in academics, in the minds of our students.</p> 
<p>● By providing state-of-the-art institutional infrastructure and excellent human resources we foster a better educational environment.</p>
<p>● Teachers who respond to students’ learning difficulties and doubts with patience are the need of the hour- considering the increasing level of toughness of problems and the cut- throat competition all around.</p>
<p><b><h2>Vision</h2></b></p>
<p>●Our vision is to be recognized as a premier educational institution that practices quality pedagogy, encourages innovation while instilling values and providing a vibrant environment for the holistic development of students into valuable global citizens. </p>
<p>●We believe that every student is precious, and it is essential that every student discovers their true potential by breaking all limitations of incompetence.</p>

<p><b><h2>How Are We Different?</h2></b></p>
<p>● We have a great team of highly qualified and experienced professors. The lecture schedule is always extremely well-planned and we make sure it is adhered to by the students as well as the professors. </p>
<p>● We would also like to mention that the study material for Std. XI, XII and MHT-CET/NEET/JEE(Main) is prepared after hours of careful planning by a well-qualified and experienced team of professors.</p>
<p>● Every Sunday, two topic-wise tests are held for students of std. XI and std. XII, commencing as per schedule.</p>
<p><b><h2>EXPECTATION FROM PARENTS</h2></b></p>
<p>● Keep enquiring about attendence and performance regularly of your ward. This will make your ward aware about your intrest in their success</p>
<p>● Please provide proper environment condusive for studies at home. Do not take your child to social meets unless and until extremely urgent. That kind of things distracts the child and wastes a lot of time.</p>
<p>● Constantly motivate your child to keep on improving his/her result. Instill self belief and confidance in him. keep your ward in good mood and let him/her enjoy studies.</p>
<p>● You have to handle him/her in the most judicious manner possible-neither interference nor indifference helps. Please applaud for a good performance. Pull him/her out of bouts of depression, if any. A pat on the back, a gentle smile, words of comfort ….. can work wonders.</p>
<p>● You have to yourself be a role model for your child through your actions & gestures</p>
<p>● A factor of major concern is your child’s health, which may fail during the hectic schedule. He/She has to avoid outside food and water. Provide with a wholesome, nourishing home cooked diet so that he/she can tackle the gruelling schedule.</p>           

<p><b><h2>EXPECTATION FROM STUDENTS</h2></b></p>
<p>● Do not change your goal or dream to become a professional in science, just because of changing syllabus , And level of difficulty. Easy going never made legends.</p>
<p>● Be dedicated and have focus on your goal</p>
<p>● Constantly motivate your child to keep on improving his/her result. Instill self belief and confidance in him. keep your ward in good mood and let him/her enjoy studies.</p>
<p>● Heights by great men reached and kept were not obtained by sudden flight but while their companions slept, they were toiling upwards in the night. – Henry Wardsworth Longfellow</p>
<p>● Do not let any one or any thing distract you from your goal</p>
<p>● Restrict the use of things like mobile, computer games, Intenet, Facebook, Whatsapp etc. which deviate you from your goal.</p>
<p>● Be healthy compititor in studies with your friends.</p>

</b>



    </div>
    

        <div class="container-fluid">
      <footer class="row text-white" style="background-color: rgba(0, 0, 0, 0.5);">
        <div class="col-sm-4 py-3">
          <span class="mr-5 text-center font-weight-bold">follow us:</span>
          <a href="#" target="_blank"><i class="fab fa-facebook-f fa-2x"></i></a>
          <a href="#" target="_blank"><i class="fab fa-linkedin fa-2x ml-2 text-secondary clr"></i></a>
          <a href="#" target="_blank"><i class="fab fa-instagram fa-2x ml-2 text-danger clr"></i></a>
          
        </div> <!--end first column-->
        <div class="col-sm-8 text-right my-3">
          <span>©2021 Copyright Avishkar Career Point. All Rights Reserved Developed by:&nbsp;<a href="https://softwares.learingo.in/" style="color: white;">Learingo Software And Education</a></span> 

          <!-- <small class="text-uppercase font-weight-bold mr-3">design by &copy</small> -->
          <!-- <small class="ml-2"><a class="btn btn-light" href="admin/adminlogin.php">admin login</a></small> -->
        </div>
      </footer>
    </div>


</body>
</html>