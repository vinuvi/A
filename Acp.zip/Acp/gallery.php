<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="shortcut icon" href="image/L.png" type="image/png" >
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="css/all.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <style>
    .bs-example{
        margin: 20px;
    }
    body{
  margin: 0;
  padding: 0;
  font-family: "montserrat";
}
.team-section{
  background: rgb(0,0,0,0);
  text-align: center;
}
.inner-width{
  max-width: 1200px;
  margin: auto;
  padding: 40px;
  color: #333;
  overflow: hidden;
}
.team-section h1{
  font-size: 20px;
  text-transform: uppercase;
  display: inline-block;
  border-bottom: 4px solid;
  padding-bottom: 10px;
}
.pe{
  float: left;
  width: calc(100% / 3);
  overflow: hidden;
  padding: 40px 0;
  transition: 0.4s;
}
.pe:hover{
  background: rgb(0,0,0,0.2);
}
.pe img{
  width: 200px;
  height: 200px;
}
.p-name{
  margin: 16px 0;
  font-style: bold;
  color: white;
}
.p-des{
  font-style: bold;
  color: white;
}
.p-sm{
  margin-top: 12px;
}
.p-sm a{
  margin: 0 4px;
  display: inline-block;
  width: 30px;
  height: 30px;
  transition: 0.4s;
}
.p-sm a:hover{
  transform: scale(1.3);
}
.p-sm a i{
  color: white;
  line-height: 30px;
}
@media screen and (max-width:600px) {
  .pe{
    width: 100%;
  }
}
@media only screen and (min-width: 1080px){
   body{
    background-image: url("image/developerweb.jpg");
   }
   .abc{
    display: none;
   }
   .p-name,.p-des,.p-sm{
      color: black;
   }
    }
/*tablet view styling*/
    @media only screen and (max-width: 1080px){ 
      body{
    background-image: url("image/tab1.jpg");
   }
    }
@media only screen and (max-width: 400px){
    body{
    background-image: url("image/phone1.jpg");
   }
    }

  </style>

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/design.css">
    <title>Gallary</title>
</head>
<body>
    <div class="bs-example">
    <nav class="navbar navbar-expand-md sticky-top" style="background-color: rgba(0, 0, 0, 0.6);" >
        <a href="#" class="navbar-brand" style="color: white; font-weight: bold; font-size: 25px;">
          <img src="image/L.png" style="height: 70px; width: 150px;">
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse" style="background-color: #F1F0FF; border-radius: 10px; height: 30px;">
            <span class="navbar-toggler-icon">🧪</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
          <a href="" class="closebtn" onclick="closeNav" style="color:rgba(0, 0, 0, 0);">X</a>
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active"  style="color: white;font-size: 150%;">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <!-- <a href="developer.html" class="nav-item nav-link"  style="color: white;">Developer</a> -->
                 <a href="gallery.php" class="nav-item nav-link active" tabindex="-1"  style="color: white;font-size: 150%;">Gallery</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="aboutus.php" class="nav-item nav-link"  style="color: white;font-size: 150%;">About Us</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="feedback.php" class="nav-item nav-link active" tabindex="-1"  style="color: white;font-size: 150%;">Feedback</a>
            </div>
        </div>
    </nav>


<div class="team-section">
    <div class="inner-width"><div class="abc">
      <h1 style="color: white; font-weight: bold;">Meet Our Team</h1></div>
      <div class="pers">

<?php 
include_once('dbcon.php');
                                     $sql="SELECT * from gallery";
                                     $result1=$conn->query($sql);


                                    if ($result1->num_rows > 0)
                                     {
                                    
                                        while($row = $result1->fetch_assoc())
                                        {
                                            //print_r($row);exit; 
                                           // $sql_cart="SELECT * from product where delete_status='0' and  id='".$row['pid']."'";
                                           // $result_cart=$conn->query($sql_cart);
                                           // $row_cart = $result_cart->fetch_assoc();

                         ?>
        <div class="pe">
          <img src="img/<?php echo $row['profile'];?>" alt="">
          <div class="p-name"><?php echo $row['name'];?></div>
          
          <!-- <div class="p-sm">
            <a href="https://www.linkedin.com/in/shrey-nigam-710b3983/"><i class="fab fa-linkedin"></i></a>
            <a href="https://github.com/shrey6162"><i class="fab fa-github"></i></a>
            <a href="https://www.instagram.com/_._shrey_._/"><i class="fab fa-instagram"></i></a>
          </div> -->
        </div>
<?php }
}?>

      </div>

    </div>
  </div>

</body>
</html>