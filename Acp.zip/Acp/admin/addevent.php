<?php
define('TITLE','notification.php');
define('page','notification.php');
include_once('../dbcon.php');
session_start();
include('includes/header.php');
if(!isset($_SESSION['radmin']))
{
    header("location:adminlogin.php");
}

if(isset($_POST['submit']))
{
  //echo $_POST['profile'];exit;
  $path ="../img/";
  //echo $path;exit;
  $image=basename($_FILES['profile']['name']);
  //echo $image;exit;
  $image_name=$path.$image;
  if(move_uploaded_file($_FILES['profile']['tmp_name'],$image_name))
  {
    echo '<br>Upload Successfully';

  }else
  {
    echo '<br>Not Uploaded';
  }
}

if(isset($_POST['submit']))
{
  $sql="insert into gallery(name,profile,date)values('".$_POST['name']."','".$image."',now())";
  
  if($conn->query($sql)==TRUE)
  {
    echo '<script>alert("Event added successfully...")</script>';?>
    
    <script>window.location='addevent.php';</script>
  <?php
  }else
  {
    echo "Something Wrong" . $conn->error;
  }
 
}
?>

</script>
<div class="offset-md-1 offset-sm-2 col-sm-6 col-md-7" id="gob">
    <div class="col-md-7 col-sm-6 offset-md-3 text-white" style="background-color: rgba(0, 0, 0, 0.2); padding-top: 5px;">
    <h2 class="text-center mt-3" style="color: white; font-weight: bold;">Added New Events</h2>
    <form action="" method="POST" class="p-3" id="myForm" enctype="multipart/form-data">
        <div class="form-group">
            <label for="notification_title" class="font-weight-bold">Title</label>
            <input type="text" placeholder="Enter Event Name" class="form-control" name="name" require>
        </div>
        <div class="form-group">
            <label for="details" class="font-weight-bold">Image</label>
             <input type="file" placeholder="Enter Event Name" class="form-control" name="profile" require>
        </div>
        
        <button type="submit" class="btn btn-danger mt-2 p-1 font-weight-bold mr-4" name="submit" style="color: white;">Submit</button>
        <p class="alert"><?php if(isset($msg)) echo $msg ?></p>
    </form></div>
</div>
<?php
include('includes/footer.php');
?>
