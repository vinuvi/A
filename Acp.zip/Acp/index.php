<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="shortcut icon" href="image/L.png" type="image/png" >
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="css/all.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <style>
    .bs-example{
        margin: 22px;
    }
  </style>

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/design.css">
    <title>Avishkar Career Point</title>
</head>
<body>
    <div class="bs-example">
    <nav class="navbar navbar-expand-md sticky-top" style="background-color: rgba(0, 0, 0, 0.6);" >
        <a href="#" class="navbar-brand" style="color: white; font-weight: bold; font-size: 25px;">
          <img src="image/L.png" style="height: 70px; width: 160px;">&nbsp;&nbsp;&nbsp;
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse" style="background-color: #F1F0FF; border-radius: 10px; height: 30px;">
            <span class="navbar-toggler-icon">🧪</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
          <a href="" class="closebtn" onclick="closeNav" style="color:rgba(0, 0, 0, 0);">X</a>
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active"  style="color: white; font-size: 150%;">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <!-- <a href="developer.html" class="nav-item nav-link"  style="color: white;">Developer</a> -->
                 <a href="gallery.php" class="nav-item nav-link active" tabindex="-1"  style="color: white; font-size: 150%;">Gallery</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="aboutus.php" class="nav-item nav-link"  style="color: white; font-size: 150%;">About Us</a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="feedback.php" class="nav-item nav-link active" tabindex="-1"  style="color: white; font-size: 150%;">Feedback</a>
            </div>
        </div>
    </nav>

    <header class="jumbotron back-image" style="background-image: url(image/41.png);">
      <div class="heading">
       <!--  <h2 class="text-light font-weight-bold text-uppercase mb-5" style="padding-top: 80px;">Welcome to Questionnaire</h2> -->
        <a href="#registration" class="btn btn-light btnn">sign up</a>
        <a href="user/login.php" class="btn btn-light btnn">login</a>
     </div>
    </header>
    <!--registration section  start-->

    <?php  include('registration.php'); ?>

     <!--registration section  end-->


        <div class="container-fluid" >
          <h2 style="color: black;"><b>⭐ Introduction</b></h2><br>
        <div class="col-sm-12  my-12">
          
              <img src="image/b2.png"  style="float:right;width:500px;height:330px;">
            <h5>
 <p>✔️Firstly, science helps our understanding of the world around us. Everything we know about the universe, from how trees reproduce to what an atom&nbsp; is made up of, is the result of scientific research and experiment. Human progress throughout history has largely rested on advances&nbsp; in science.</p><br>
<p>✔️ Science generates solutions for everyday life and helps us to answer the great mysteries of the universe.</p><br>
<p>✔️ In other words, science is one of the most important channels of knowledge.</p><br>
<p>✔️ ACP (Avishkar Career Point) Science Classes offers coaching for F.Y.J.C (11th) and S.Y.J.C (12th) Standard students. </p><br>
<p>✔️ The Maharashtra State Board of Secondary & Higher Secondary Education is also known as MSBSHSE is responsible for creating the Maharashtra State Board syllabus for class 11 and conducting the exam. </p><br>
<p>✔️ The schools affiliated to this board are required to adopt the syllabus framed by the MSBSHSE and accept any changes set by the Board.</p> <br>
<p>✔️ So students should work hard with dedication so that they can step up to the next standard with a clear concept on all the subjects.</p>
        
          </h5>
        </div>
      </div>

      <div class="container-fluid" >
          <h2 style="color: black; float: left;"><b>⭐ Why Acp ?</b></h2>
        <div class="col-sm-11  my-3">
          
              <img src="image/b1.png"  style="float:left;width:490px;height:330px;">
            <h5>
 <p>&nbsp;✔️ Complete & Relevant study Material and notes.</p><br>
<p>&nbsp;✔️  Affordable fees and manageable installments.</p><br>
<p>&nbsp;✔️  Daily Test, Unit Test & Revision Test on each topic.</p><br>
<p>&nbsp;✔️ Special learning for IIT-JEE / NEET/ MHT-CET and other entrance exams. </p><br>
<p>&nbsp;✔️ Quality Infrastructure. </p><br>
<p>&nbsp;✔️ Central Place to suit your requirement.</p> <br>
<p>&nbsp;✔️Personalized attention to all student by friendly Management Staff & Faculty members</p>
<p>&nbsp;✔️Highly competitive responsive & motivating environment encouraging you to achieve success.</p>
<p>&nbsp;✔️ Effective classroom discussion.</p>
<p>&nbsp;✔️  Daily home assignment.</p>
       
          </h5>
        </div>
      </div>


    <!--footer section-->
    <div class="container-fluid">
      <footer class="row text-white" style="background-color: rgba(0, 0, 0, 0.5);">
        <div class="col-sm-4 py-3">
          <span class="mr-5 text-center font-weight-bold">follow us:</span>
          <a href="#" target="_blank"><i class="fab fa-facebook-f fa-2x"></i></a>
          <a href="#" target="_blank"><i class="fab fa-linkedin fa-2x ml-2 text-secondary clr"></i></a>
          <a href="#" target="_blank"><i class="fab fa-instagram fa-2x ml-2 text-danger clr"></i></a>
          
        </div> <!--end first column-->
        <div class="col-sm-8 text-right my-3">
          <span>©2021 Copyright Avishkar Career Point. All Rights Reserved Developed by:&nbsp;<a href="https://softwares.learingo.in/" style="color: white;">Learingo Software And Education</a></span> 

          <!-- <small class="text-uppercase font-weight-bold mr-3">design by &copy</small> -->
          <small class="ml-2"><a class="btn btn-light" href="admin/adminlogin.php">admin login</a></small>
        </div>
      </footer>
    </div>
    <link rel="stylesheet" href="css/whats.css">
                            <a href="https://api.whatsapp.com/send?phone=+918805766019" class="float" target="_blank">
                            <img id="loading" src="image/w.ico">
                            </a>
    <!--End footer section-->
  
     <!-- Boostrap JavaScript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/all.min.js"></script>
  <script src="js/custom.js"></script>
</body>
</html>