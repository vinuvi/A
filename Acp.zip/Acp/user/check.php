<?php
session_start();
//echo $_SESSION['email'];exit;
if(!isset($_SESSION["remail"]))
{
	echo $_SESSION[''];exit;
	header("location:../index.php");


}
?>